# Minecraft Effekt-LED-Steuerung via MQTT

Dieses Projekt sendet RGB-Farben über MQTT an einen externen MQTT-Broker basierend auf gewählten Minecraft-Effekten.

## Aufbau

- Node-RED Flow: Sendet JSON `{ "r": 255, "g": 0, "b": 0 }` an Topic `led/`
- Effekt-Auswahl triggert eine Farbe
- Kein Mikrocontroller notwendig
- Funktioniert mit jedem MQTT-kompatiblen Client (z. B. LED-Anzeige)

## Setup

1. Installiere Node-RED
2. Importiere die Datei `flows.json` im Editor
3. Konfiguriere deinen MQTT-Broker in Node-RED
4. Passe ggf. die RGB-Farben an deine LED-Logik an

## Beispiel

Effekt: `minecraft:jump_boost` → LED-Farbe: `{"r":0,"g":255,"b":127}`

## Hinweis

- Der MQTT-Broker ist vorkonfiguriert mit `192.168.1.100:1883`
- Passe dies in Node-RED an deinen Server an